#!/usr/bin/env/ python

import prompt


def welcome_user(string):
    return prompt.string(string)
